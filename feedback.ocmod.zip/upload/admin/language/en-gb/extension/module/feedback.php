<?php
// Heading
$_['heading_title']    = 'Feedback';

// Text
$_['text_extension']   = 'Extensions';
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Feedback Module!';
$_['text_edit']        = 'Edit Feedback Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_name']       = 'Module\'s name';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Feedback Module!';
